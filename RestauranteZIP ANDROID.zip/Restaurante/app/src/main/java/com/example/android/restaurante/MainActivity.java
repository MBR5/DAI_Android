package com.example.android.restaurante;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText mail, contrasena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mail = (EditText)findViewById(R.id.etMailA);
        contrasena = (EditText)findViewById(R.id.etContrasenaA);
    }

    public void redirect(View V){
        Intent intent = new Intent(this, CreaUsuario.class);
        startActivity(intent);
    }

    public void ingresar(View V){
        Intent intent = new Intent(this, UserMain.class);

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "Administracion", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();

        try {
            //proceso para verificar que existe el usuario, traer su nombre y mail
            String correo = mail.getText().toString();
            String contra = contrasena.getText().toString();

            if(correo.length() == 0 || contra.length()== 0){
                Toast.makeText(this, "Asegúrese de llenar las casillas requeridas", Toast.LENGTH_LONG).show();
            }
            else {

//create table usuarios (nombre text, apellido text, mail text primary key, contrasena text)

                Cursor fila = db.rawQuery("select nombre from usuarios where mail = '" + correo + "' and contrasena = '" + contra + "';", null);

                if (fila.moveToFirst()) {
                    Bundle bundle = new Bundle();
                    bundle.putString("nombre", fila.getString(0));
                    bundle.putString("mail", correo);
                    intent.putExtras(bundle);

                    startActivity(intent);
                    finish();
                } else {
                    mail.setText("");
                    contrasena.setText("");

                    Toast.makeText(this, "Los datos ingresados son incorrectos", Toast.LENGTH_LONG).show();
                }
            }
        } catch(Exception ex){
            Toast.makeText(this, "Algo no jalo en ingresar", Toast.LENGTH_LONG).show();
        }
    }
}
