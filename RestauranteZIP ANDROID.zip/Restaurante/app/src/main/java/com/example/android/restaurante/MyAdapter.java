package com.example.android.restaurante;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class MyAdapter  extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    public String[] dataSet;

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView mTextView;

        public MyViewHolder(TextView v){
            super(v);
            mTextView = v;
        }
    }

    //Este constructor depende del tipo de dataSet que se tenga
    public MyAdapter(String[] myDataSet){
        dataSet = myDataSet;
    }

    //crea nuevas views, y es llamado por el layout manager
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        //creamos las nuevas views
        TextView v = (TextView)LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_menu, viewGroup, false);
        MyViewHolder mv = new MyViewHolder(v);

        return mv;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.mTextView.setText(dataSet[i]);


    }

    @Override
    public int getItemCount() {
        return dataSet.length;
    }
}
