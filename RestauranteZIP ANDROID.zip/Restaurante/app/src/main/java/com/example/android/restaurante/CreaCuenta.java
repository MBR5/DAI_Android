package com.example.android.restaurante;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CreaCuenta extends AppCompatActivity {
    private ListView productos;
    private TextView total;
    private EditText propina;
    private StringBuilder cad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crea_cuenta);

        cad = new StringBuilder();
        productos = (ListView)findViewById(R.id.lvProductos);
        total = (TextView)findViewById(R.id.tvTotal);
        propina = (EditText)findViewById(R.id.etPropina);
        propina.setText("0");
        total.setText("0");

        //Creo la lista de los items que se mostrarán en la ListView
        ArrayList<String> nombres = new ArrayList<String>();
        nombres.add("Vino tinto           - $110"); //110
        nombres.add("Vino blanco          - $100"); //100
        nombres.add("Sopa de tortilla     - $75"); //75
        nombres.add("Sopa de municiones   - $70"); //70
        nombres.add("Ensalada césar       - $70"); //70
        nombres.add("Ensalada primaveral  - $80"); //80
        nombres.add("Filete Mignon        - $130"); //130
        nombres.add("Pescado a la plancha - $115"); //115
        nombres.add("Helado con frutas    - $65"); //65

        //Con esto hago la conexión entre mi dataSet (ArrayList, en este caso) y la ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_selectable_list_item, nombres);
        productos.setAdapter(adapter);

        //Le doy funcionalidad a la ListView para cuando el usuario elija algún Item
        productos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                double tot = Double.parseDouble(total.getText().toString());

                switch(position){
                    case 0:
                        tot += 110;
                        total.setText(tot+"");
                        cad.append("Vino tinto| ");
                        break;
                    case 1:
                        tot += 100;
                        total.setText(tot+"");
                        cad.append("Vino blanco| ");
                        break;
                    case 2:
                        tot += 75;
                        total.setText(tot+"");
                        cad.append("Sopa de tortilla| ");
                        break;
                    case 3:
                        tot += 70;
                        total.setText(tot+"");
                        cad.append("Sopa de municiones| ");
                        break;
                    case 4:
                        tot += 70;
                        total.setText(tot+"");
                        cad.append("Ensalada césar| ");
                        break;
                    case 5:
                        tot += 80;
                        total.setText(tot+"");
                        cad.append("Ensalada primaveral| ");
                        break;
                    case 6:
                        tot += 130;
                        total.setText(tot+"");
                        cad.append("Filete mignon| ");
                        break;
                    case 7:
                        tot += 115;
                        total.setText(tot+"");
                        cad.append("Pescado a la plancha| ");
                        break;
                    case 8:
                        tot += 65;
                        total.setText(tot+"");
                        cad.append("Helado con frutas| ");
                        break;
                }
            }
        });


    }

    public void daPropina(View V){

        try {
            double tot = Double.parseDouble(total.getText().toString());
            double propa = Double.parseDouble(propina.getText().toString());

            tot *= (1 + propa / 100);

            total.setText(tot + "");

        } catch(Exception ex){
            Toast.makeText(this, "Ingrese datos válidos", Toast.LENGTH_LONG).show();
        }
        propina.setText("");
    }

    public void limpiar(View v){
        cad = new StringBuilder();
        total.setText("0");
        propina.setText("0");
    }

    public void crear(View v){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCuentas", null ,1);
        SQLiteDatabase db = admin.getWritableDatabase();

        try {
            String consumos = cad.toString();
            String mail = getIntent().getExtras().getString("mail");
            double totl = Double.parseDouble(total.getText().toString());
            //Toast.makeText(this, "el mail es "+mail, Toast.LENGTH_LONG).show();

            if(totl > 0){
                ContentValues registro = new ContentValues();
                registro.put("mail", mail);
                registro.put("total", totl);
                registro.put("consumo", consumos);

                db.insert("cuentas", null, registro);
                db.close();
                Toast.makeText(this, "Cuenta creada", Toast.LENGTH_LONG).show();
                total.setText("0");
            }
            else{
                Toast.makeText(this, "No se pueden crear cuentas vacías", Toast.LENGTH_LONG).show();
            }


        } catch(Exception ex){
            Toast.makeText(this, "Algo no jaló: "+ex.getMessage(), Toast.LENGTH_LONG).show();

        }


    }
}
