package com.example.android.restaurante;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Menu extends AppCompatActivity{
    private ListView myListView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        myListView = (ListView)findViewById(R.id.myListView);

        ArrayList<String> nombres = new ArrayList<String>();
        nombres.add("Vino tinto           - $110\nTinto español, importado de España para tus bellos labios"); //110
        nombres.add("Vino blanco          - $100\nVino blanco de uvas blancas"); //100
        nombres.add("Sopa de tortilla     - $75\nSopa mexicana como ella misma"); //75
        nombres.add("Sopa de municiones   - $70\nLa no-me-falles Sopa Knor"); //70
        nombres.add("Ensalada césar       - $70\nLa siempre confiable"); //70
        nombres.add("Ensalada primaveral  - $80\nEnsalada hipster con frutas"); //80
        nombres.add("Filete Mignon        - $130\nCorte fileteado a las brasas"); //130
        nombres.add("Pescado a la plancha - $115\nNemo"); //115
        nombres.add("Helado con frutas    - $65\nHeladito pal frío"); //65


        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nombres);

        myListView.setAdapter(arrayAdapter);



    }



}
