package com.example.android.restaurante;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class SitioWeb extends AppCompatActivity {
    private WebView miWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sitio_web);

        miWeb = (WebView)findViewById(R.id.webView);
        miWeb.loadUrl("https://mariachiroll.mx/");
    }
}
