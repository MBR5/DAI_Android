package com.example.android.restaurante;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MisCuentas extends AppCompatActivity {
    private TextView ver;
    private String mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_cuentas);

        ver = (TextView)findViewById(R.id.tvCuentas);
        mail = this.getIntent().getExtras().getString("mail");
    }

    public void darCuentas(View v){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "AdminCuentas", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();

//db.execSQL("create table cuentas (idCuenta integer primary key autoincrement, mail text references usuarios, total real, consumo text)");
        try{
            Cursor fila = db.rawQuery("select idCuenta, total, consumo from cuentas where mail = '"+mail+"'", null);


            if(fila.moveToFirst()){
                ver.setText(ver.getText()+"\n"+"Id: " + fila.getInt(0) + " Total: " + fila.getDouble(1) + "\t\n Descripción: " + fila.getString(2));
                while(fila.move(1)) {
                    ver.setText(ver.getText()+"\n"+"Id: " + fila.getInt(0) + " Total: " + fila.getDouble(1) + "\t\n Descripción: " + fila.getString(2));
                }
                Toast.makeText(this, "Cuentas cargadas exitosamente", Toast.LENGTH_LONG).show();
                db.close();
            }else{
                ver.setText("No has creado ninguna cuenta");
            }
        }catch(Exception ex){
            Toast.makeText(this, "Nope: "+ex.getMessage(),Toast.LENGTH_LONG).show();
        }


    }
}
