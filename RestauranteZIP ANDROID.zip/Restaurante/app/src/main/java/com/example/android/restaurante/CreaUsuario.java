package com.example.android.restaurante;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class CreaUsuario extends AppCompatActivity {
    private EditText nombre, apellido, mail, contrasena, contrasena2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crea_usuario);

        nombre = (EditText)findViewById(R.id.etNombre);
        apellido = (EditText)findViewById(R.id.etApellido);
        mail = (EditText)findViewById(R.id.etMail);
        contrasena = (EditText)findViewById(R.id.etContrasena);
        contrasena2 = (EditText)findViewById(R.id.etContrasena2);

    }

    public void redirect(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void registrar(View v){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,"Administracion", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();

        try {
            String correo = mail.getText().toString();

            Cursor fila = db.rawQuery("select nombre from usuarios where mail = '"+correo+"'",null);

            if(!fila.moveToFirst()) {



                String nom = nombre.getText().toString();
                String ape = apellido.getText().toString();
                String contra = contrasena.getText().toString();
                String contra2 = contrasena2.getText().toString();

                if(correo.length() == 0 || nom.length() == 0 || ape.length() == 0 || contra.length() == 0 || contra2.length() ==0)
                    Toast.makeText(this, "Asegúrese de llenar todos los campos requeridos", Toast.LENGTH_LONG).show();
                else {

                    if (contra.equals(contra2)) {

//usuarios (nombre text, apellido text, mail text primary key, contrasena text)
                        ContentValues registro = new ContentValues();
                        registro.put("nombre", nom);
                        registro.put("apellido", ape);
                        registro.put("mail", correo);
                        registro.put("contrasena", contra);

                        db.insert("usuarios", null, registro);
                        db.close();

                        Toast.makeText(this, "Registro exitoso", Toast.LENGTH_LONG).show();

                        redirect(v); //tras registrarme, me regresa a la pantalla principal
                        finish();
                    } else {
                        contrasena.setText("");
                        contrasena2.setText("");
                        Toast.makeText(this, "Las contraseñas deben coincidir", Toast.LENGTH_LONG).show();
                    }
                }
            } else{
                mail.setText("");
                Toast.makeText(this, "El mail dado ya está registrado en otra cuenta", Toast.LENGTH_LONG).show();
            }
        } catch(Exception ex){
            Toast.makeText(this, "Ingresa correctamente los datos en las casillas correspondientes", Toast.LENGTH_LONG).show();
        }
    }

    public void baja(View v){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "Administracion", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();

        try {
            String correo = mail.getText().toString();
            String contra = contrasena.getText().toString();
            Cursor fila = db.rawQuery("select nombre from usuarios where mail = '"+correo+ "' and contrasena = '"+ contra + "'", null);

            if(fila.moveToFirst()){
               db.execSQL("delete from usuarios where mail = '" + correo + "' and contrasena = '" + contra + "'");
    /*dudisima*/           db.delete("usuarios", "mail = '"+correo+"' and contrasena = '" + contra +"'", null);
    //si con el execSQL ya se borra o le tengo que poner delete directo
                mail.setText("");
                contrasena.setText("");
               Toast.makeText(this, "Usuario eliminado exitosamente", Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(this, "No se encontró un usuario con el mail o contraseña dados", Toast.LENGTH_LONG).show();
            }

        } catch(Exception ex){
            Toast.makeText(this, "Asegúrese de haber llenado el campo del correo y la contraseña correctamente", Toast.LENGTH_LONG).show();
        }
    }
}

